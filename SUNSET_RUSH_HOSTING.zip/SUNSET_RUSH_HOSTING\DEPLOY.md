# Hosting SUNSET RUSH publicly

The game already has the right shape for a public website: one Node process serves
`SUNSET_RUSH.html` over HTTP and hosts the WebSocket rooms at `/ws`. The browser
client automatically uses `wss://<same host>/ws` when the page is served over HTTPS.

The only missing piece is a public computer to run that process. You do not need a
local server after it is deployed.

> I cannot create the public URL for you from this workspace: that needs your own
> Google Cloud account, billing account and `gcloud` login. Everything needed to
> deploy is in this folder.

## Is Google Cloud a good idea?

**Yes, Google Cloud Run is a good fit**, especially if you already use Google Cloud:

- It runs the included Dockerfile directly.
- It provides a public HTTPS URL and works with WSS automatically.
- No VM or OS administration.
- Scales down when idle (or stays warm with minimum instances).
- Google's WebSocket support is documented here:
  https://cloud.google.com/run/docs/triggering/websockets

The important caveat is that rooms are held **in memory**. Therefore:

- Use **exactly one Cloud Run instance** (`--max-instances=1`). If two instances
  run, two players with the same room code can land on different servers and
  never see each other.
- Use `--min-instances=1` if you want the room list to survive idle periods.
  With zero minimum instances, a cold start/redeploy clears all rooms.
- WebSocket connections have a Cloud Run request timeout; the command below sets
  the maximum (3600 seconds). Your races take far less than an hour.
- A redeploy or instance restart clears open rooms. Players can simply create a
  new room.

If you do not want to deal with GCP billing/project setup, **Render** or **Fly.io**
are simpler for a small friends-only game. Render's free tier sleeps when idle,
which also clears rooms.

## Deploy to Google Cloud Run

Install the Google Cloud CLI, then run from this `SUNSET_RUSH` folder:

```bash
gcloud auth login
gcloud config set project YOUR_PROJECT_ID

gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com

gcloud run deploy sunset-rush \
  --source . \
  --region asia-east1 \
  --platform managed \
  --allow-unauthenticated \
  --port 8080 \
  --timeout 3600 \
  --min-instances 1 \
  --max-instances 1 \
  --cpu 1 \
  --memory 512Mi
```

After it finishes, print the public URL:

```bash
gcloud run services describe sunset-rush \
  --region asia-east1 \
  --format "value(status.url)"
```

Open that `https://...run.app` URL on any device. This is the whole website:
solo play works immediately, and ONLINE creates/joins public rooms with no local
download or server.

### Choose another region

`asia-east1` (Taiwan) is a reasonable default for East Asia. Other options include
`asia-southeast1` (Singapore), `europe-west1` (Belgium) and `us-central1` (Iowa).
Use a region close to your players; all players connect to the same service.

### Custom domain

Cloud Run's generated `*.run.app` URL is enough to play. A custom domain can be
mapped later under **Cloud Run → Domain mappings**, or with a global external
Application Load Balancer. HTTPS/WSS certificates are managed automatically.

## Test the container locally (optional)

Docker is not required for Cloud Run because `gcloud run deploy --source .` builds
the image in Cloud Build, but if Docker is installed:

```bash
docker build -t sunset-rush .
docker run --rm -p 8080:8080 sunset-rush
```

Then open `http://localhost:8080`.

## Simpler alternative: Render

1. Put this project in a GitHub/GitLab repository.
2. In Render, create a **Web Service** from that repository.
3. Runtime: **Docker** (uses the included Dockerfile), or Node with:
   - Build command: `npm install --omit=dev`
   - Start command: `node tools/serve.mjs`
4. Render injects `PORT`; `tools/serve.mjs` already reads it.
5. Use the generated HTTPS URL.

Render WebSockets are supported. The free tier spins down after idle, which kills
in-memory rooms; use a paid always-on instance if that matters.

## What visitors need

- A modern browser and a network connection.
- Nothing else.
- The host creates a room and shares the 4-letter code.
- Everyone must select the same circuit and weather before joining.
- Up to four racers per room.

## Operational notes

- The server has `/healthz` for health checks.
- `PORT` and `HOST` are environment-configurable.
- No database is used. Room state, readiness, chat-free lobby data and results are
  in memory.
- The generated Google Cloud URL is public. Room codes are the only access control;
  do not use this setup for private/competitive events without adding accounts,
  passwords and persistence.
- A persistent public deployment should eventually move rooms to Redis/Firestore
  and support multiple instances. For a friends-only 2–4 player game, one instance
  is simpler and cheaper.
